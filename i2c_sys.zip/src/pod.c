#include "pod.h"
#include <stdio.h>

bool pod_init(pod_t *p)
{
    // Check for pod. If found, set info, return true. Else return false.
}

void pod_deinit(pod_t *p)
{
    // Remove from pod pool
    memset(p, 0, sizeof(p));
    p->init = false;
}

void pod_enable(pod_t *p);
void pod_disable(pod_t *p);