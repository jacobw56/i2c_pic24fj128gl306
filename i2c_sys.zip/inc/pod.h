/**
 * @file pod.h
 * @author Walt
 * @brief pod driver
 * @version 0.1
 * @date 2025-10-22
 *
 * @copyright Copyright (c) 2025
 *
 */

#ifndef __POD_H__
#define __POD_H__

#include <stdbool.h>
#include <stdint.h>

#include "eeprom.h"

/**
 * This is just an example, but this could keep track of valid scents.
 * However, it requires a FW update to change it, so probably not the
 * best unless it's needed.
 */
typedef enum
{
    NO_SCENT,
    CUSTOM_SCENT = 0xff00 // Leaving a little headroom
} pod_scent_t;

typedef struct
{
    bool init;
    unsigned int position;
    pod_scent_t scent;
    uint16_t remaining;  // Volume remaining, 0xffff is full, 0x0000 is empty
    uint16_t duty_cycle; // Pods have their own duty cycle for optimal atomization
} pod_t;

void pod_init(pod_t *p);
void pod_deinit(pod_t *p);
void pod_enable(pod_t *p);
void pod_disable(pod_t *p);

#endif /* __POD_H__ */